const descInput = document.getElementById("desc") as HTMLInputElement;
const amtInput = document.getElementById("amt") as HTMLInputElement;
const addBtn = document.getElementById("addBtn") as HTMLButtonElement;
const expenseList = document.getElementById("expenseList") as HTMLUListElement;
const totalDisplay = document.getElementById("total") as HTMLSpanElement;

let total1 :number = 0;

addBtn.addEventListener('click',()=>{

    const description = descInput.value.trim();
    const amount = parseFloat(amtInput.value);

    if (description && !isNaN(amount)){

        const li = document.createElement('li')
        li.textContent = `${description} : Rs.${amount}`
        expenseList.appendChild(li);

        total1 +=amount;
        totalDisplay.textContent = total1.toFixed(2);;

        descInput.value ='';
        amtInput.value ='';

    }
    else{
        alert('Enter all fields ')
    } 
})

